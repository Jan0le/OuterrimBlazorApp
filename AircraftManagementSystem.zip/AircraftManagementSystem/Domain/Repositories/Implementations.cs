namespace Domain.Repositories;

public class Implementations
{
    
}