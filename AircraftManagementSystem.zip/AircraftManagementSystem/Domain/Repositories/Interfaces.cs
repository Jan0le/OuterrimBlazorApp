namespace Domain.Repositories;

public class Interfaces
{
    
}