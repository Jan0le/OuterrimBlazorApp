using AircraftManagementSystem.Shared.Models;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Model.Entities;

namespace Domain.Configuration;

public class OuterrimDbContext : DbContext
{
    public DbSet<Aircraft> Aircrafts { get; set; }
    public DbSet<Compartment> Compartments { get; set; }
    public DbSet<Mercenary> Mercenaries { get; set; }
    public DbSet<Crew> Hugos { get; set; }
    public DbSet<AircraftSpecification> AircraftSpezifications { get; set; }
    public DbSet<CrimeSyndicate> CrimeSyndicates { get; set; }
    public DbSet<MercenaryReputation> MercenaryReputations { get; set; }
    public DbSet<Machinery> Machineries { get; set; }
    public DbSet<Weapon> Weapons { get; set; }
    public DbSet<EnergySystem> EnergySystems { get; set; }
    public DbSet<EnvironmentalSystem> EnvironmentalSystems { get; set; }

    public OuterrimDbContext(DbContextOptions<OuterrimDbContext> options) : base(options) {

    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.Entity<Aircraft>()
            .HasOne<AircraftSpecification>(a => a.Spezification)
            .WithMany()
            .HasForeignKey(a => a.SpecificationId);
        builder.Entity<Compartment>()
            .HasOne(c => c.Aircraft)
            .WithMany()
            .HasForeignKey(c => c.Aircraft_Id);
        
        builder.Entity<Crew>()//EntityTypeBuilder<Crew>
            .HasKey(c => new {c.Aircraft_ID, c.Mercenary_Id});

        builder. Entity<Crew>()//EntityTypeBuilder<Crew>
            .HasOne (  c  => c. Aircraft) // ReferenceNavigationBuilder<Crew,Aircraft>
            .WithMany()
            .HasForeignKey (c => c.Aircraft_ID);

        builder. Entity<Crew>() //EntityTypeBuilder<Crew>
            . HasOne (c => c.Mercenary) // ReferenceNavigationBuilder<Crew,Mercenary>
            .WithMany()
            .HasForeignKey(c => c.Mercenary_Id);
    }
}