using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Domain.Entities;
using Model.Entities;

namespace AircraftManagementSystem.Shared.Models
{
    [Table("AIRCRAFTS")]
    public class Aircraft
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption. Identity) ]
        [Column( name: "AIRCRAFT_ID") ]
        public int Id { get; set; }
        public AircraftSpecification Spezification { get; set; }
        [Column( name: "SPECIFICATION_ID") ]
        public int SpecificationId { get; set; }

        [Required, Range(0, 100)]
        [Column( name: "FUEL")]
        public int Fuel { get; set; }

        [Required, Range(0, 10)]
        [Column( name: "SPEED") ]
        public int Speed { get; set; }

        [Required, Range(0, 10)]
        [Column( name: "ALTITUDE")]
        public int Altitude { get; set; }

        [Required, StringLength(100)]
        [Column( name: "NAME") ]
        public string Name { get; set; }
    }
}