using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model.Entities;

[Table(name: "AIRCRAFT_SPECIFICATIONS")]
public class AircraftSpecification
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column(name: "AIRCRAFT_SPECIFICATION_ID")]
    public int Id { get; set; }

    [Required, Range(0, 20)]
    [Column(name: "STRUCTURE")]
    public int Structure { get; set; }

    [Required, Range(0, 20)]
    [Column(name: "FUEL_CAPACITY")]
    public int FuelCapacity { get; set; }

    [Required, Range(0, 20)]
    [Column(name: "MIN_SPEED")]
    public int MinSpeed { get; set; }

    [Required, Range(0, 20)]
    [Column(name: "MAX_SPEED")]
    public int MaxSpeed { get; set; }

    [Required, Range(0, 20)]
    [Column(name: "MAX_ALTITUDE")]
    public int MaxAltitude { get; set; }

    [Required, StringLength(200)]
    [Column(name: "SPECIFICATION_CODE")]
    public string SpecificationCode { get; set; }
}