using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Domain.Entities;
namespace AircraftManagementSystem.Shared.Models
{
    [Table("COMPARTMENTS")]
    public class Compartment
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("COMPARTMENT_ID")]
        public int Id { get; set; }
        
        public Aircraft Aircraft { get; set; }
        
        [Column("AIRCRAFT_ID")]
        
        public int Aircraft_Id { get; set; }
    }
}