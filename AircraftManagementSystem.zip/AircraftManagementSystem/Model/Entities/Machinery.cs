using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Entities;
    
[Table ( name: "MACHINERIES_BT")]

    public class Machinery {
    [Key, DatabaseGenerated(DatabaseGeneratedOption. Identity)]
    [Column ( name: "MACHINERY_ID") ]
    public int Id { get; set; }

    }
