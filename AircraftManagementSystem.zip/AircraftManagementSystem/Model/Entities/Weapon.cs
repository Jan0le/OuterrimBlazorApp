using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Entities;

[Table("WEAPONS")]
public class Weapon : Machinery
{
    
}